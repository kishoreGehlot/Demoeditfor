<?php
class Help extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable="helpcontents";
}
?>