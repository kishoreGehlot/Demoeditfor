<?php
class Transactionhistory extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable="wallets";  
}
?>