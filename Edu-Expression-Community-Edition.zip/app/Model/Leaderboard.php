<?php
class Leaderboard extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable="exam_results";  
}
?>