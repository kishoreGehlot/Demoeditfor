<?php
class Forgot extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable="students";
}
?>