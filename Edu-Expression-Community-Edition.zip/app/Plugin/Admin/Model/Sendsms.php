<?php
class Sendsms extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable=false;
}
?>