<?php
class Sendemail extends AppModel
{
  public $validationDomain = 'validation';
  public $useTable=false;
}
?>